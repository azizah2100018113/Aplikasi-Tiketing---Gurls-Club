<?php
session_start();
class Connect_db {
    private $servername = "localhost";
    private $db_name = "db_webtiket";
    private $username = "root";
    private $password = "";
    private $connect_db;

    public function executeQuery($query) {
        // Contoh implementasi eksekusi query (ganti dengan fungsi query sebenarnya)
        $result = $this->connect_db->query($query);
        return $result;
    }


    public function getConnection() {
        return $this->connect_db;
    }

    // Koneksi Database
    function __construct() {
        $this->connect_db = mysqli_connect($this->servername, $this->username, $this->password, $this->db_name);

        if (mysqli_connect_errno()) {
            echo "Gagal menyambungkan kedalam database -> " . mysqli_connect_error();
            exit();
        }
    }
    // End Of Koneksi Database

    // Get Database From Id
    function db_From_Id($sql){
		$query = mysqli_query($this->connect_db,$sql);

		$result = [];

		while ($data = mysqli_fetch_array($query)) {
			$result[] = $data;
		}

		return $result;
	}    
    // End Of Get Database From ID

    // Signup
    function signUp($username, $no_wa, $email, $password){
        // hash password
        $secure_password = password_hash($password, PASSWORD_DEFAULT);
        // end hash password

        $sql = "INSERT INTO user (id, username, no_wa, email, password) VALUES ('', '$username', '$no_wa', '$email', '$secure_password')";
        
        // Cek Koneksi
        if (mysqli_query($this->connect_db, $sql)) {
            echo '<script>';
            echo 'alert("Your account has been successfully created, please log in to continue")';
            echo '</script>';
        }else{
            echo '<script>';
            echo 'alert("Your account failed to be created, please contact the admin if there are any problems")';
            echo '</script>';
        }
        // End Of Cek Koneksi
    }
    // End Of Signup

    // Sign in
    function signIn($username, $password){
        
        $sql = "SELECT * FROM user WHERE username='$username'";
        $result = mysqli_query($this->connect_db, $sql);

        // cek username
        // if true
        if (mysqli_num_rows($result) > 0) {
            // cek password
            $row = mysqli_fetch_assoc($result);
            if( password_verify($password, $row["password"]) ){
                $_SESSION["login"] = $row["id"];
                header("Location: ../order/index.php");
                
            };
        }else{
            echo '<script>';
            echo 'alert("The username or password you entered is incorrect")';
            echo '</script>';
        }
        
        

    }
    // End Of Sign in

    // Order Tiket
    function set_Pesanan($id_tiket, $order_id, $email, $catatan, $rek_pengirim, $namarek_pengirim, $bank_pengirim, $jenis_pesanan, $bank_penerima, $total_pembayaran, $waktu_pesanan,$bukti_pembayaran, $status, $link_status, $warna_status){
        $sql = "INSERT INTO user_order(id,id_tiket ,order_id, email, catatan, rek_pengirim, namarek_pengirim, bank_pengirim, jenis_pesanan, bank_penerima, total_pembayaran, waktu_pesanan,bukti_pembayaran, status, link_status, warna_status)
               VALUES
               (NULL, '$id_tiket', '$order_id', '$email', '$catatan', '$rek_pengirim', '$namarek_pengirim', '$bank_pengirim', '$jenis_pesanan', '$bank_penerima', '$total_pembayaran', '$waktu_pesanan', '$bukti_pembayaran', '$status', '$link_status', '$warna_status') 
        ";
        if(mysqli_query($this->connect_db, $sql)){
            echo '<script>';
            echo 'alert("Order Successfully Made, Please Wait for Admin to Confirm, If There Are Problems You Can Contact 0856-7712-2272")';
            echo '</script>';
        }
    }

    // End Of Order Tiket

    // Upload Gambar Ke File
    function upload_Gambar($gambar){
        
        $nama_file = $_FILES["gambar"]["name"];
        
        $error = $_FILES["gambar"]["error"];
        $tmpname = $_FILES["gambar"]["tmp_name"];

        if ($error === 4) {
            echo "<script>";
            echo "alert('Select an image first')";
            echo "</script>";
            return false;
        }

        // cek ekstensi gambar
        $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
        $ekstensiGambar = explode('.', $nama_file);
        $ekstensiGambar = strtolower(end($ekstensiGambar));
        if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
            echo "<script>";
            echo "alert('Yang anda upload bukan gambar')";
            echo "</script>";
            return false;
        }
        // generate nama baru
        $namaFileBaru = uniqid();
        $namaFileBaru .= '.';
        $namaFileBaru .= $ekstensiGambar;

        // lolos check , dan upload
        move_uploaded_file($tmpname, '../db_images/' . $namaFileBaru);
        return $namaFileBaru;
    }

    // End Of Upload Gambar Ke File

    // Add Admin
    function register_Admin($username, $password){
        $secure_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO admin (id, username, password) VALUES ('', '$username', '$secure_password')";
        if(mysqli_query($this->connect_db, $sql)){
            echo "<script>";
            echo "alert('The admin account has been successfully created')";
            echo "</script>";
        }else{
            echo "<script>";
            echo "alert('Admin account failed to create')";
            echo "</script>";
        }
        header("Location: index.php");
    }
    // End Of Add Admin

    // Signin Admin
    function sign_In_Admin($username, $password){
        
        $sql = "SELECT * FROM admin WHERE username='$username'";
        $result = mysqli_query($this->connect_db, $sql);

        // cek username
        // if true
        if (mysqli_num_rows($result) > 0) {
            // cek password
            $row = mysqli_fetch_assoc($result);
            if( password_verify($password, $row["password"]) ){
                $_SESSION["login_admin"] = $row["id"];
                header("Location: index.php");
                exit;
            }
        }else{
            echo '<script>';
            echo 'alert("The username or password you entered is incorrect")';
            echo '</script>';
        }
        
        

    }
    // End Of Signin Admin
}
