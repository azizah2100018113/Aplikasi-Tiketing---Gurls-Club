<!-- JIKA PESANAN DITOLAK ADMIN -->
<?php
echo "<script>";
echo "alert('Your order has been rejected by admin, if there are any problems, please contact 0856-8899-7812')";
echo "</script>";

exit;
?>