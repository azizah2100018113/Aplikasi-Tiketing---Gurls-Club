<div class="footer_section layout_padding">
   <div class="container">
      <div class="row">
         <div class="col-lg-6 col-sm-12">
            <h4 class="information_text" style="font-family: Arial, Helvetica, sans-serif ;">Informasi</h4>
            <p class="dummy_text" style="text-align: justify; font-family: Arial, Helvetica, sans-serif ;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim </p>
         </div>
         <div class="col-lg-3 col-sm-6">
            <div class="information_main">
               <h4 class="information_text" style="font-family: Arial, Helvetica, sans-serif ;">Akses Link</h4>
               <p class="call_text" style="font-family: Arial, Helvetica, sans-serif ;"><a href="category.php">Pengisi Acara</a></p>
               <p class="call_text" style="font-family: Arial, Helvetica, sans-serif ;"><a href="login.php">Dapatkan Tiket</a></p>
               <p class="call_text" style="font-family: Arial, Helvetica, sans-serif ;"><a href="contact.php">Chat Support</a></p>
               <p class="call_text" style="font-family: Arial, Helvetica, sans-serif ;"><a href="#"></a></p>
            </div>
         </div>
         <div class="col-lg-3 col-sm-6">
            <div class="information_main">
               <h4 class="information_text" style="font-family: Arial, Helvetica, sans-serif ;">Contact Us</h4>
               <p class="call_text" style="font-family: Arial, Helvetica, sans-serif ;"><a>+01 1234567890 (Rika)</a></p>
               <p class="call_text" style="font-family: Arial, Helvetica, sans-serif ;"><a>+01 9876543210 (Andi)</a></p>
               <p class="call_text" style="font-family: Arial, Helvetica, sans-serif ;"><a>demo@gmail.com</a></p>

            </div>
         </div>
      </div>
      <div class="copyright_section">
         <h1 class="copyright_text" style="font-family: Arial, Helvetica, sans-serif ;">
            Copyright 2023 All Right Reserved <a href="#"> gurls club</a>
      </div>
   </div>
</div>